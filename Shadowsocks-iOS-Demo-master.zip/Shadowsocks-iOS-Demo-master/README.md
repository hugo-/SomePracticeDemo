# Shadowsocks-iOS-Demo
Demo how to build an iOS project with shadowsocks buildin.


* Clone this project.
* Open project file in Finder.
* Drag the Shadowsocks-iOS-Demo/shadowsocks folder to XCode, confirm the dialog keep the default options.
* Copy the code from the method application:didFinishLaunchingWithOptions: in AppDelegate.m. Don't forget the imports.
* Replace the remote server configs with yours.
* You should wait about 1s after the app launched and then start network request.
