//
//  AppDelegate.h
//  ShadowsocksDemo
//
//  Created by Jason Hsu on 15/7/2.
//  Copyright (c) 2015年 Jason Hsu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

