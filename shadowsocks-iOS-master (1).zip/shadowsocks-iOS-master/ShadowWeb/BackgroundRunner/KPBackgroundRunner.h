//
//  KPBackgroundRunner.h
//  PrettyTunnel
//
//  Created by zhang fan on 14-8-12.
//
//

#import <Foundation/Foundation.h>

@interface KPBackgroundRunner : NSObject

@property (atomic, assign) BOOL enable;

@end
