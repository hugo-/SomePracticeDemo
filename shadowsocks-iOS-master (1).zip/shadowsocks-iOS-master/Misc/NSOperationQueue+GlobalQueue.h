//
//  NSOperationQueue+GlobalQueue.h
//  PrettyTunnel
//
//  Created by zhang fan on 14-8-5.
//
//

#import <Foundation/Foundation.h>

@interface NSOperationQueue (GlobalQueue)

+ (instancetype)globalQueue;

@end
