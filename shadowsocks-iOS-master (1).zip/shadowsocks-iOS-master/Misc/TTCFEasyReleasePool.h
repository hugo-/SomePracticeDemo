//
//  TTCFEasyRelease.h
//  PrettyTunnel
//
//  Created by zhang fan on 15/1/16.
//
//

#import <Foundation/Foundation.h>

@interface TTCFEasyReleasePool : NSObject

- (void)autorelease:(CFTypeRef)obj;

@end
